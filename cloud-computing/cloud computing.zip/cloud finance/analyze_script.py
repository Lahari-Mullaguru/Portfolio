
import random
import argparse
import logging
import boto3
import json
import yfinance as yf
from datetime import date, timedelta
from pandas_datareader import data as pdr

# Initialize logging
logging.basicConfig(level=logging.INFO)


def main(args):
    logging.info(f"Starting analysis with args: {args}")

    yf.pdr_override()
    today = date.today()
    timePast = today - timedelta(days=1095)
    data = yf.download('GOOG', start=timePast, end=today)

    # Add two columns to allow for Buy and Sell signals
    data['Buy'] = 0
    data['Sell'] = 0

    var95_list = []
    var99_list = []
    profit_loss_list = []

    # Generate buy and sell signals
    for i in range(2, len(data)):
        body = 0.01

        # Three Soldiers
        if (data.Close[i] - data.Open[i]) >= body  \
    and data.Close[i] > data.Close[i-1]  \
    and (data.Close[i-1] - data.Open[i-1]) >= body  \
    and data.Close[i-1] > data.Close[i-2]  \
    and (data.Close[i-2] - data.Open[i-2]) >= body:
            data.at[data.index[i], 'Buy'] = 1


        # Three Crows
        if (data.Open[i] - data.Close[i]) >= body  \
    and data.Close[i] < data.Close[i-1] \
    and (data.Open[i-1] - data.Close[i-1]) >= body  \
    and data.Close[i-1] < data.Close[i-2]  \
    and (data.Open[i-2] - data.Close[i-2]) >= body:
            data.at[data.index[i], 'Sell'] = -1

    var95_list = []
    var99_list = []
    profit_loss_list = []
    p = args.profit_loss_days
    
    for i in range(args.history, len(data) - p):
        if args.transaction == 'buy' and data['Buy'][i] == 1:
            price_change = data['Close'][i + p] - data['Close'][i]
            profit_loss = price_change  # Profit if price goes up, loss if price goes down
        elif args.transaction == 'sell' and data['Sell'][i] == -1:
            price_change = data['Close'][i] - data['Close'][i + p]
            profit_loss = price_change  # Profit if price goes down, loss if price goes up
        else:
            profit_loss = 0

        profit_loss_list.append(profit_loss)

    # Compute Value at Risk 
    for i in range(args.history, len(data)):
        if data['Buy'][i] == 1 or data['Sell'][i] == -1:
            mean = data['Close'][i-args.history:i].pct_change(1).mean()
            std = data['Close'][i-args.history:i].pct_change(1).std()
            simulated = [random.gauss(mean, std) for _ in range(args.shots)]
            simulated.sort(reverse=True)
            var95 = simulated[int(len(simulated) * 0.95)]
            var99 = simulated[int(len(simulated) * 0.99)]
            var95_list.append(var95)
            var99_list.append(var99)

    total_profit_loss = sum(profit_loss_list) if profit_loss_list else 0

    logging.info(f'All var95 values: {var95_list}')
    logging.info(f'All var99 values: {var99_list}')
    logging.info(f'profit_loss: {profit_loss_list}')
    logging.info(f'Total profit/loss: {total_profit_loss:.2f}')

    # Store the results in S3
    s3_client = boto3.client('s3')
    result_data = {
        'var95': var95_list,
        'var99': var99_list,
        'profit_loss_list': profit_loss_list,
        'profit_loss': total_profit_loss
    }
    s3_client.put_object(Bucket='storeresults', Key=f'analysis_results/{args.unique_id}.json', Body=json.dumps(result_data))

    return result_data

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--history', type=int, required=True)
    parser.add_argument('--shots', type=int, required=True)
    parser.add_argument('--transaction', type=str, required=True, choices=['buy', 'sell'])
    parser.add_argument('--profit_loss_days', type=int, required=True)
    parser.add_argument('--unique_id', type=str, required=True)
    args = parser.parse_args()
    results = main(args)
    print(results)