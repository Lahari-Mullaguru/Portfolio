from flask import Flask, request, jsonify
import requests

app = Flask(__name__)

instance_storage = []
audit_id_storage = None
max_count_storage= None

@app.route('/warmup', methods=['POST'])
def warmup():
    global audit_id_storage
    global instance_storage
    global max_count_storage
    data = request.get_json()
    lambda_url = "https://9owh477364.execute-api.us-east-1.amazonaws.com/warmup"
    lambda_data = {
        "command": "launch",
        "s":data.get('s'),
        "r": int(data.get('r', 1))
    }
    try:
        response = requests.post(lambda_url, json=lambda_data)
        response_data = response.json()
        instance_ids = response_data.get('instance_ids', [])
        audit_id = response_data.get('audit_id')
        max_count= response_data.get('audit_id')
        # Update instance storage with launched instance IDs
        instance_storage.extend(instance_ids)
        audit_id_storage = audit_id  # Store the audit_id
        max_count_storage= max_count
        return jsonify({"result": "ok"}), 200
    except requests.exceptions.RequestException as e:
        return jsonify({"error": "Failed to launch instances", "details": str(e)}), 500

@app.route('/scaled_ready', methods=['GET'])
def scaled_ready():
    try:
        global instance_storage
        global max_count_storage
        lambda_url = "https://9owh477364.execute-api.us-east-1.amazonaws.com/warmup"
        lambda_data = {
            "command": "check_status",
            "instance_ids": instance_storage,
            "audit_id": audit_id_storage,
            "max_count":max_count_storage
        }
        response = requests.post(lambda_url, json=lambda_data)
        warm_status = response.json().get('warm', False)
        return jsonify({"warm": warm_status}), 200
    except requests.exceptions.RequestException as e:
        return jsonify({"error": "Internal Server Error", "details": str(e)}), 500

@app.route('/get_warmup_cost', methods=['GET'])
def get_warmup_cost():
    try:
        lambda_url = "https://9owh477364.execute-api.us-east-1.amazonaws.com/warmup"
        lambda_data = {
            "command": "price"
        }
        response = requests.post(lambda_url, json=lambda_data)
        return jsonify(response.json()), response.status_code
    except requests.exceptions.RequestException as e:
        return jsonify({"error": "Internal Server Error", "details": str(e)}), 500

    
@app.route('/analyse', methods=['POST'])
def analyze():
    try:
        global instance_storage
        global audit_id_storage
        data = request.get_json()
        lambda_url = "https://9owh477364.execute-api.us-east-1.amazonaws.com/warmup"
        instance_ids = instance_storage
        lambda_data = {
            "command": "analyze",
            "instance_ids": instance_ids,
            "h": int(data.get('h')),
            "d": int(data.get('d')),
            "t": data.get('t'),
            "p": int(data.get('p')),
            "audit_id": audit_id_storage
        }
        response = requests.post(lambda_url, json=lambda_data)
        response.raise_for_status()  # This will raise an exception for HTTP error responses

        # Return the JSON response from Lambda
        return jsonify(response.json()), response.status_code
    except requests.exceptions.RequestException as e:
        app.logger.error(f"Error communicating with Lambda: {str(e)}", exc_info=True)
        return jsonify({"error": "Failed to communicate with Lambda", "details": str(e)}), 500
    except Exception as e:
        app.logger.error(f"Internal Server Error: {str(e)}", exc_info=True)
        return jsonify({"error": "Internal Server Error", "details": str(e)}), 500
    
    
@app.route('/get_sig_vars9599', methods=['GET'])
def get_sig_vars9599():
    try:
        lambda_url = "https://9owh477364.execute-api.us-east-1.amazonaws.com/warmup"
        lambda_data = {'command': 'get_sig_vars9599'}
        response = requests.post(lambda_url, json=lambda_data)
        return jsonify(response.json()), response.status_code
    except requests.exceptions.RequestException as e:
        return jsonify({"error": "Internal Server Error", "details": str(e)}), 500

@app.route('/get_avg_vars9599', methods=['GET'])
def get_avg_vars9599():
    try:
        lambda_url = "https://9owh477364.execute-api.us-east-1.amazonaws.com/warmup"
        lambda_data = {'command': 'get_avg_vars9599'}
        response = requests.post(lambda_url, json=lambda_data)
        return jsonify(response.json()), response.status_code
    except requests.exceptions.RequestException as e:
        return jsonify({"error": "Internal Server Error", "details": str(e)}), 500

@app.route('/get_sig_profit_loss', methods=['GET'])
def get_sig_profit_loss():
    try:
        lambda_url = "https://9owh477364.execute-api.us-east-1.amazonaws.com/warmup"
        lambda_data = {'command': 'get_sig_profit_loss'}
        response = requests.post(lambda_url, json=lambda_data)
        return jsonify(response.json()), response.status_code
    except requests.exceptions.RequestException as e:
        return jsonify({"error": "Internal Server Error", "details": str(e)}), 500

@app.route('/get_tot_profit_loss', methods=['GET'])
def get_tot_profit_loss():
    try:
        lambda_url = "https://9owh477364.execute-api.us-east-1.amazonaws.com/warmup"
        lambda_data = {'command': 'get_tot_profit_loss'}
        response = requests.post(lambda_url, json=lambda_data)
        return jsonify(response.json()), response.status_code
    except requests.exceptions.RequestException as e:
        return jsonify({"error": "Internal Server Error", "details": str(e)}), 500

def generate_google_chart_url(var95, var99, var95_avg, var99_avg):
    base_url = "https://chart.googleapis.com/chart"
    # Prepare data for chart
    chd = f"t:{','.join(map(str, var95))}|{','.join(map(str, var99))}|{','.join([str(var95_avg)]*len(var95))}|{','.join([str(var99_avg)]*len(var99))}"
    params = {
        "cht": "lc",  # Chart type: line chart
        "chs": "700x500",  # Chart size
        "chd": chd,  # Chart data
        "chdl": "VaR 95%|VaR 99%|Avg VaR 95%|Avg VaR 99%",  # Chart legend
        "chxt": "x,y",  # Axes
        "chxr": "1,-0.1,0.1",  # y-axis range (example, adjust as needed)
        "chco": "FF0000,0000FF,00FF00,FFA500"  # Line colors
    }

    # Create URL
    chart_url = requests.Request('GET', base_url, params=params).prepare().url
    return chart_url


@app.route('/get_chart_url', methods=['GET'])
def get_chart_url():
    try:
        # Get signal values
        lambda_url = "https://9owh477364.execute-api.us-east-1.amazonaws.com/warmup"
        lambda_data = {'command': 'get_sig_vars9599'}
        sig_vars_response = requests.post(lambda_url, json=lambda_data)
        if sig_vars_response.status_code != 200:
            return jsonify({"error": "Failed to retrieve signal values"}), sig_vars_response.status_code
        sig_vars_data = sig_vars_response.json()
        var95 = sig_vars_data['var95']
        var99 = sig_vars_data['var99']

        # Get average values
        lambda_data = {'command': 'get_avg_vars9599'}
        avg_vars_response = requests.post(lambda_url, json=lambda_data)
        if avg_vars_response.status_code != 200:
            return jsonify({"error": "Failed to retrieve average values"}), avg_vars_response.status_code
        avg_vars_data = avg_vars_response.json()
        var95_avg = avg_vars_data['var95']
        var99_avg = avg_vars_data['var99']

        # Generate chart URL
        chart_url = generate_google_chart_url(var95, var99, var95_avg, var99_avg)
        return jsonify({"url": chart_url}), 200
    except requests.exceptions.RequestException as e:
        return jsonify({"error": "Internal Server Error", "details": str(e)}), 500

@app.route('/get_time_cost', methods=['GET'])
def get_time_cost():
    try:
        lambda_url = "https://9owh477364.execute-api.us-east-1.amazonaws.com/warmup"
        lambda_data = {
            "command": "get_time_cost"
        }
        response = requests.post(lambda_url, json=lambda_data)
        return jsonify(response.json()), response.status_code
    except requests.exceptions.RequestException as e:
        return jsonify({"error": "Internal Server Error", "details": str(e)}), 500
    
@app.route('/get_audit', methods=['GET'])
def get_audit():
    try:
        global audit_id_storage
        lambda_url = "https://9owh477364.execute-api.us-east-1.amazonaws.com/warmup"
        lambda_data = {
            "command": "final_audit",
            "audit_id": audit_id_storage
        }
        response = requests.post(lambda_url, json=lambda_data)
        
        if response.status_code == 200:
            return jsonify(response.json()), response.status_code
        else:
            return jsonify({"error": "Failed to retrieve data", "details": response.json()}), response.status_code
    except requests.exceptions.RequestException as e:
        return jsonify({"error": "Internal Server Error", "details": str(e)}), 500

    
@app.route('/reset', methods=['GET'])
def reset():
    try:
        lambda_url = "https://9owh477364.execute-api.us-east-1.amazonaws.com/warmup"
        lambda_data = {'command': 'reset'}
        response = requests.post(lambda_url, json=lambda_data)
        return jsonify(response.json()), 200
    except requests.exceptions.RequestException as e:
        return jsonify({"error": "Internal Server Error", "details": str(e)}), 500
    
@app.route('/terminate', methods=['GET'])
def terminate():
    try:
        global instance_storage
        lambda_url = "https://9owh477364.execute-api.us-east-1.amazonaws.com/warmup"
        lambda_data = {'command': 'terminate',"instance_ids": instance_storage}
        response = requests.post(lambda_url, json=lambda_data)
        return jsonify({"result": "ok"}), response.status_code
    except requests.exceptions.RequestException as e:
        return jsonify({"error": "Internal Server Error", "details": str(e)}), 500
    
@app.route('/scaled_terminated', methods=['GET'])
def scaled_terminated():
    try:
        global instance_storage
        lambda_url = "https://9owh477364.execute-api.us-east-1.amazonaws.com/warmup"
        lambda_data = {
            "command": "check_termination",
            "instance_ids": instance_storage
        }
        response = requests.post(lambda_url, json=lambda_data)
        response_data = response.json()
        terminated = response_data.get('terminated', False)
        return jsonify({"terminated": terminated}), 200
    except requests.exceptions.RequestException as e:
        return jsonify({"error": "Internal Server Error", "details": str(e)}), 500
    
@app.route('/get_endpoints', methods=['GET'])
def get_endpoints():
    try:
        lambda_url = "https://9owh477364.execute-api.us-east-1.amazonaws.com/warmup"
        lambda_data = {
            "command": "get_endpoints"
        }
        response = requests.post(lambda_url, json=lambda_data)
        return jsonify(response.json()), response.status_code
    except requests.exceptions.RequestException as e:
        return jsonify({"error": "Internal Server Error", "details": str(e)}), 500
    
    
if __name__ == '__main__':
    app.run(debug=True)
