import json
import boto3
import logging
import datetime
import uuid
import time
import decimal

# Initialize logging
logging.getLogger().setLevel(logging.INFO)

instance_storage = {"active_instances": []}
r= None
audit_id = str(uuid.uuid4())

# Initialize AWS resources
ec2_client = boto3.client('ec2')
ssm_client = boto3.client('ssm')
s3_client = boto3.client('s3')
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('AuditLogs')
bucket_name = 'storeresults'

# Static pricing data for EC2 instances (costs per hour in USD)
instance_costs = {
    't2.micro': 0.0116,
    't2.small': 0.023,
    't2.medium': 0.0464
}

def lambda_handler(event, context):
    try:
        # Parse the incoming JSON data
        data = json.loads(event['body']) if 'body' in event else event

        # Determine the command
        command = data.get('command')
        if not command:
            return {'statusCode': 400, 'body': json.dumps({'error': 'Invalid command'})}

        # Execute the appropriate function based on the command
        if command == 'launch':
            return handle_launch(data)
        elif command == 'check_status':
            return handle_check_status(data)
        elif command == 'price':
            return handle_price(data)
        elif command == 'analyze':
            return handle_analyze(data)
        elif command == 'get_endpoints':
            return handle_get_endpoints()
        elif command == 'reset':
            return handle_reset()
        elif command == 'terminate':
            return handle_terminate(data)
        elif command == 'check_termination':
            return handle_check_termination(data)
        elif command == 'get_time_cost':
            return handle_get_time_cost(data)
        elif command == 'final_audit':
            return handle_final_audit(data)
        elif command in ['get_sig_vars9599', 'get_avg_vars9599', 'get_sig_profit_loss', 'get_tot_profit_loss']:
            return handle_var_and_profit_loss(command)
        else:
            return {'statusCode': 400, 'body': json.dumps({'error': 'Invalid command'})}
    except Exception as e:
        logging.error(f"Error processing event: {str(e)}", exc_info=True)
        return {'statusCode': 500, 'body': json.dumps({'error': str(e)})}

def handle_launch(data):
    global audit_id
    global instance_storage
    global r
    try:
        service = data.get('s')
        replicas = int(data.get('r', 1))
        r=replicas
        user_data_script = '''#!/bin/bash
        aws s3 cp s3://analyzescript/analyze_script.py /home/ec2-user/analyze_script.py
        chmod +x /home/ec2-user/analyze_script.py
        systemctl enable amazon-ssm-agent
        systemctl start amazon-ssm-agent
        '''

        response = ec2_client.run_instances(
            ImageId='ami-08a748047ee0dbdd0',
            InstanceType='t2.micro',
            MinCount=1,
            MaxCount=replicas,
            KeyName='lahari',
            SecurityGroupIds=['sg-0ededa4c3049c0b1d'],
            IamInstanceProfile={'Arn': 'arn:aws:iam::626618432354:instance-profile/LabInstanceProfile'},
            UserData=user_data_script
        )
        instance_ids = [instance['InstanceId'] for instance in response['Instances']]
        
        # Wait for a few seconds to ensure all attributes are populated
        time.sleep(5)
        
        # Describe the instances to get updated attributes
        described_instances = ec2_client.describe_instances(InstanceIds=instance_ids)
        
        start_time = datetime.datetime.now()
        
        for reservation in described_instances['Reservations']:
            for instance in reservation['Instances']:
                instance_id = instance['InstanceId']
                instance_type = instance.get('InstanceType', 't2.micro')
                public_ip = instance.get('PublicIpAddress', '')

                instance_storage['active_instances'].append({
                    'id': instance_id,
                    'type': instance_type,
                    'start_time': start_time.isoformat(),
                    'public_ip': public_ip
                })

        # Store s and r in DynamoDB
        table.put_item(Item={
            'audit_id': audit_id,
            's': service,
            'r': replicas,
            'timestamp': start_time.isoformat()
        })
        logging.info(f"Launched instances: {instance_ids}")
        return {
            'statusCode': 200,
            'body': json.dumps({
                'result': 'ok',
                'instance_ids': instance_ids,
                'audit_id': audit_id,
                'MaxCount': replicas
            })
        }
    except Exception as e:
        logging.error(f"Error launching instances: {str(e)}", exc_info=True)
        return {'statusCode': 500, 'body': json.dumps({'error': str(e)})}

def handle_check_status(data):
    global instance_storage
    global r
    try:
        print(r)
        instance_ids = data.get('instance_ids')
        logging.info(f"Checking status for instances: {instance_ids}")
        if not instance_ids:
            return {'warm': False}
        
        ec2 = boto3.resource('ec2')
        instances = list(ec2.instances.filter(InstanceIds=instance_ids))
        instance_states = {instance.id: instance.state['Name'] for instance in instances}

        running_instances = [instance_id for instance_id, state in instance_states.items() if state == 'running']

        # Clean up terminated instances dynamically
        instance_storage['active_instances'] = [
            instance for instance in instance_storage['active_instances'] if instance['id'] in instance_states and instance_states[instance['id']] not in ['terminated', 'shutting-down', 'stopping', 'stopped']
        ]
        logging.info(f"Active instances after cleanup: {instance_storage['active_instances']}")
        
        is_warm = len(running_instances) == r
        return {'warm': is_warm}
    except Exception as e:
        logging.error(f"Error checking instance statuses: {str(e)}", exc_info=True)
        return {'statusCode': 500, 'body': json.dumps({'error': str(e)})}

def handle_price(data):
    try:
        total_cost = 0
        total_hours = 0
        current_time = datetime.datetime.now(datetime.timezone.utc)

        active_instances = get_active_instances()

        for instance_info in active_instances:
            instance_type = instance_info['type']
            start_time = instance_info['launch_time']
            duration_hours = (current_time - start_time).total_seconds() / 3600
            rate = instance_costs.get(instance_type, 0)
            instance_cost = rate * duration_hours

            total_cost += instance_cost
            total_hours += duration_hours

        return {
            'statusCode': 200,
            'body': json.dumps({"billable_time": total_hours, "cost": total_cost})
        }
    except Exception as e:
        logging.error(f"Error calculating price: {str(e)}", exc_info=True)
        return {'statusCode': 500, 'body': json.dumps({'error': str(e)})}

def handle_analyze(data):
    try:
        global audit_id
        ec2_client = boto3.client('ec2')
        ssm_client = boto3.client('ssm')
        s3_client = boto3.client('s3')
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table('AuditLogs')
        
        # Fetch running instances from EC2
        running_instances = get_active_instances()
        
        # Filter instances by those that are running
        instance_ids = [instance['id'] for instance in running_instances if instance['type'] == 't2.micro']

        if not instance_ids:
            return {'statusCode': 500, 'body': json.dumps({'error': 'No running instances available'})}

        logging.info(f"Running instances to use for analysis: {instance_ids}")

        h = int(data.get('h'))
        d = int(data.get('d'))
        t = data.get('t')
        p = int(data.get('p'))
        bucket_name = 'storeresults'
        prefix = 'analysis_results'

        num_instances = len(instance_ids)
        shots_per_instance = d // num_instances
        remaining_shots = d % num_instances

        responses = []
        command_ids = []
        unique_ids = [str(uuid.uuid4()) for _ in range(num_instances)]

        for i, instance_id in enumerate(instance_ids):
            shots = shots_per_instance + (1 if i < remaining_shots else 0)
            unique_id = unique_ids[i]

            script_command = f'python3 /home/ec2-user/analyze_script.py --history {h} --shots {shots} --transaction {t} --profit_loss_days {p} --unique_id {unique_id}'

            combined_command = (
                'sudo yum update -y && '
                'sudo yum remove python3-requests -y && '
                'sudo pip install boto3 yfinance pandas_datareader && '
                f'{script_command}'
            )

            response = ssm_client.send_command(
                InstanceIds=[instance_id],
                DocumentName='AWS-RunShellScript',
                Parameters={'commands': [combined_command]},
                OutputS3BucketName=bucket_name,
                OutputS3KeyPrefix=f'ssm-output/{unique_id}/'
            )

            command_ids.append(response['Command']['CommandId'])
            responses.append({
                'instance_id': instance_id,
                'command_id': response['Command']['CommandId'],
                'unique_id': unique_id
            })

        logging.info(f"SSM commands sent: {responses}")

        uploaded_files = set()
        expected_files = set(f'analysis_results/{unique_id}/' for unique_id in unique_ids)

        while len(uploaded_files) < num_instances:
            response = s3_client.list_objects_v2(Bucket=bucket_name, Prefix='analysis_results/')
            if 'Contents' in response:
                uploaded_files = set(obj['Key'] for obj in response['Contents'] if any(unique_id in obj['Key'] for unique_id in unique_ids))
            time.sleep(5)

        logging.info(f"Expected files: {expected_files}")
        logging.info(f"Uploaded files: {uploaded_files}")

        audit_id = audit_id
        if not audit_id:
            return {'statusCode': 400, 'body': json.dumps({'error': 'No audit_id provided'})}

        # Initialize DynamoDB Table resource
        table = dynamodb.Table('AuditLogs')

        table.update_item(
            Key={'audit_id': audit_id},
            UpdateExpression="SET #h = :h, #d = :d, #t = :t, #p = :p",
            ExpressionAttributeNames={
                '#h': 'h',
                '#d': 'd',
                '#t': 't',
                '#p': 'p'
            },
            ExpressionAttributeValues={
                ':h': h,
                ':d': d,
                ':t': t,
                ':p': p
            }
        )
        logging.info('error')

        return {
            'statusCode': 200,
            'body': json.dumps({'result': 'ok'})
        }
    except Exception as e:
        logging.error(f"Error in analysis_results: {str(e)}", exc_info=True)
        return {'statusCode': 500, 'body': json.dumps({'error': str(e)})}

def handle_get_endpoints():
    try:
        global instance_storage
        logging.info(f"Current instance storage: {instance_storage['active_instances']}")
        endpoints = {
            f"endpoint": f"curl -d '{"{\"h\": 101, \"d\": 10000, \"t\": \"sell\", \"p\": 7}"}' http://{instance['public_ip']}"
            for i, instance in enumerate(instance_storage['active_instances'], 1)
        }
        logging.info(f"Retrieved endpoints: {endpoints}")
        return {
            'statusCode': 200,
            'body': json.dumps(endpoints)
        }
    except Exception as e:
        logging.error(f"Error retrieving endpoints: {str(e)}", exc_info=True)
        return {'statusCode': 500, 'body': json.dumps({'error': str(e)})}

def handle_reset():
    try:
        prefix = 'analysis_results/'
        response = s3_client.list_objects_v2(Bucket=bucket_name, Prefix=prefix)
        if 'Contents' in response:
            for obj in response['Contents']:
                s3_client.delete_object(Bucket=bucket_name, Key=obj['Key'])
            return {
                'statusCode': 200,
                'body': json.dumps({'result': 'ok'})
            }
        else:
            return {
                'statusCode': 400,
                'body': json.dumps({'error': 'No files to delete'})
            }
    except Exception as e:
        logging.error(f"Error resetting analysis results: {str(e)}", exc_info=True)
        return {'statusCode': 500, 'body': json.dumps({'error': str(e)})}

def handle_terminate(data):
    try:
        # Retrieve running instances
        response = ec2_client.describe_instances(
            Filters=[{'Name': 'instance-state-name', 'Values': ['running']}]
        )
        
        # Extract instance IDs
        instance_ids = [
            instance['InstanceId'] 
            for reservation in response['Reservations']
            for instance in reservation['Instances']
        ]
        
        logging.info(f"Running instances to terminate: {instance_ids}")
        
        if instance_ids:
            # Terminate instances
            terminate_response = ec2_client.terminate_instances(InstanceIds=instance_ids)
            logging.info(f"Terminate response: {terminate_response}")
            
            terminated_instances = [instance['InstanceId'] for instance in terminate_response.get('TerminatingInstances', [])]
            logging.info(f"Successfully terminated instances: {terminated_instances}")

            if len(terminated_instances) != len(instance_ids):
                logging.warning(f"Not all instances were terminated. Expected: {instance_ids}, Terminated: {terminated_instances}")

            return {
                'statusCode': 200,
                'body': json.dumps({'result': 'ok'})
            }
        else:
            logging.info("No running instances to terminate")
            return {
                'statusCode': 400,
                'body': json.dumps({'error': 'No instances to terminate'})
            }
    except Exception as e:
        logging.error(f"Error terminating instances: {str(e)}", exc_info=True)
        return {'statusCode': 500, 'body': json.dumps({'error': str(e)})}

def handle_check_termination(data):
    try:
        instance_ids = data.get('instance_ids', [])
        if not instance_ids:
            return {
                'statusCode': 200,
                'body': json.dumps({'terminated': True})
            }

        response = ec2_client.describe_instance_status(InstanceIds=instance_ids, IncludeAllInstances=True)
        instance_statuses = response.get('InstanceStatuses', [])

        terminated_instances = []
        for status in instance_statuses:
            if status['InstanceState']['Name'] == 'terminated':
                terminated_instances.append(status['InstanceId'])

        all_terminated = len(terminated_instances) == len(instance_ids)
        logging.info(f"Termination status: {all_terminated}. Terminated instances: {terminated_instances}")
        return {
            'statusCode': 200,
            'body': json.dumps({'terminated': all_terminated})
        }
    except Exception as e:
        logging.error(f"Error checking termination status: {str(e)}", exc_info=True)
        return {'statusCode': 500, 'body': json.dumps({'error': str(e)})}

def get_active_instances():
    try:
        response = ec2_client.describe_instances(Filters=[{'Name': 'instance-state-name', 'Values': ['running']}])
        instances = []
        for reservation in response['Reservations']:
            for instance in reservation['Instances']:
                instances.append({
                    'id': instance['InstanceId'],
                    'type': instance['InstanceType'],
                    'launch_time': instance['LaunchTime']
                })
        logging.info(f"Active instances retrieved: {instances}")
        return instances
    except Exception as e:
        logging.error(f"Error retrieving active instances: {str(e)}", exc_info=True)
        return []

def handle_get_time_cost(data):
    try:
        total_cost = 0
        total_hours = 0
        current_time = datetime.datetime.now(datetime.timezone.utc)

        active_instances = get_active_instances()

        for instance_info in active_instances:
            instance_type = instance_info['type']
            start_time = instance_info['launch_time']
            duration_hours = (current_time - start_time).total_seconds() / 3600
            rate = instance_costs.get(instance_type, 0)
            instance_cost = rate * duration_hours

            total_cost += instance_cost
            total_hours += duration_hours

        return {
            'statusCode': 200,
            'body': json.dumps({"time": total_hours, "cost": total_cost})
        }
    except Exception as e:
        logging.error(f"Error calculating time and cost: {str(e)}", exc_info=True)
        return {'statusCode': 500, 'body': json.dumps({'error': str(e)})}

# Function to handle the final audit
def handle_final_audit(data):
    global audit_id
    try:
        audit_id=audit_id
        if not audit_id:
            return {'statusCode': 400, 'body': json.dumps({'error': 'No audit_id provided'})}

        # Retrieve the audit log entry
        response = table.get_item(Key={'audit_id': audit_id})
        if 'Item' not in response:
            return {'statusCode': 404, 'body': json.dumps({'error': 'Audit ID not found'})}
        
        audit_log = response['Item']
        
        # Get analysis results from S3
        file_keys = list_analysis_results()
        all_var95 = []
        all_var99 = []
        total_profit_loss = 0

        for file_key in file_keys:
            result_data = get_results_from_s3(file_key)
            all_var95.extend(result_data['var95'])
            all_var99.extend(result_data['var99'])
            total_profit_loss += result_data['profit_loss']

        var95_avg = sum(all_var95) / len(all_var95) if all_var95 else 0
        var99_avg = sum(all_var99) / len(all_var99) if all_var99 else 0
        
        # Get time and cost
        time_cost_data = handle_get_time_cost({})

        # Log the structure of time_cost_data for debugging
        logging.info(f"time_cost_data: {time_cost_data}")

        # Ensure time_cost_data is parsed correctly
        if time_cost_data['statusCode'] == 200:
            body_data = json.loads(time_cost_data['body']) if isinstance(time_cost_data['body'], str) else time_cost_data['body']
            time = body_data.get('time', 0)
            cost = body_data.get('cost', 0)
        else:
            time = 0
            cost = 0
        
        # Set decimal context to allow Inexact and Rounded conditions
        decimal.getcontext().traps[decimal.Inexact] = False
        decimal.getcontext().traps[decimal.Rounded] = False

        # Convert float to Decimal
        total_profit_loss = decimal.Decimal(total_profit_loss)
        var95_avg = decimal.Decimal(var95_avg)
        var99_avg = decimal.Decimal(var99_avg)
        time = decimal.Decimal(time)
        cost = decimal.Decimal(cost)

        # Add results to audit log and update in DynamoDB
        update_expression = "SET profit_loss = :profit_loss, av95 = :av95, av99 = :av99, #time = :time, cost = :cost"
        expression_attribute_values = {
            ':profit_loss': total_profit_loss,
            ':av95': var95_avg,
            ':av99': var99_avg,
            ':time': time,
            ':cost': cost
        }
        expression_attribute_names = {'#time': 'time'}

        table.update_item(
            Key={'audit_id': audit_id},
            UpdateExpression=update_expression,
            ExpressionAttributeValues=expression_attribute_values,
            ExpressionAttributeNames=expression_attribute_names
        )

        # Update local audit_log dictionary to reflect new values
        audit_log.update({
            'profit_loss': float(total_profit_loss),
            'av95': float(var95_avg),
            'av99': float(var99_avg),
            'time': float(time),
            'cost': float(cost)
        })

        # Retrieve all entries from the table
        scan_response = table.scan()
        all_audit_logs = scan_response.get('Items', [])

        # Format the response
        formatted_response = [format_audit_log(entry) for entry in all_audit_logs]

        return {
            'statusCode': 200,
            'body': json.dumps(formatted_response)
        }
    except Exception as e:
        logging.error(f"Error retrieving final audit: {str(e)}", exc_info=True)
        return {'statusCode': 500, 'body': json.dumps({'error': str(e)})}

def format_audit_log(entry):
    return {
        's': entry.get('s'),
        'r': entry.get('r'),
        'h': entry.get('h', 0),
        'd': entry.get('d', 0),
        't': entry.get('t'),
        'p': entry.get('p', 0),
        'profit_loss': float(entry.get('profit_loss', 0)),
        'av95': float(entry.get('av95', 0)),
        'av99': float(entry.get('av99', 0)),
        'time': float(entry.get('time', 0)),
        'cost': float(entry.get('cost', 0))
    }

def list_analysis_results():
    prefix = 'analysis_results/'
    response = s3_client.list_objects_v2(Bucket=bucket_name, Prefix=prefix)
    if 'Contents' in response:
        return [content['Key'] for content in response['Contents'] if content['Key'] != prefix]
    else:
        return []

def get_results_from_s3(file_key):
    try:
        result_object = s3_client.get_object(Bucket=bucket_name, Key=file_key)
        result_data = result_object['Body'].read().decode('utf-8')
        logging.info(f"File content for {file_key}: {result_data[:100]}...")  # Log the first 100 characters
        return json.loads(result_data)
    except Exception as e:
        logging.error(f"Error reading S3 object {file_key}: {str(e)}", exc_info=True)
        raise

def handle_var_and_profit_loss(command):
    try:
        file_keys = list_analysis_results()
        all_var95 = []
        all_var99 = []
        all_profit_loss_list = []
        total_profit_loss = 0

        logging.info(f"Processing files: {file_keys}")

        for file_key in file_keys:
            result_data = get_results_from_s3(file_key)
            all_var95.extend(result_data['var95'])
            all_var99.extend(result_data['var99'])
            all_profit_loss_list = result_data['profit_loss_list']
            total_profit_loss = result_data['profit_loss']

        if command == 'get_sig_vars9599':
            response_body = {
                'var95': all_var95,
                'var99': all_var99
            }

        elif command == 'get_avg_vars9599':
            var95_avg = sum(all_var95) / len(all_var95) if all_var95 else 0
            var99_avg = sum(all_var99) / len(all_var99) if all_var99 else 0
            response_body = {
                'var95': var95_avg,
                'var99': var99_avg
            }

        elif command == 'get_sig_profit_loss':
            response_body = {
                'profit_loss': all_profit_loss_list
            }

        elif command == 'get_tot_profit_loss':
            response_body = {
                'profit_loss': total_profit_loss
            }

        else:
            response_body = {'error': 'Invalid command'}
            return {
                'statusCode': 400,
                'body': json.dumps(response_body)
            }

        return {
            'statusCode': 200,
            'body': json.dumps(response_body)
        }

    except Exception as e:
        logging.error(f"Error processing {command}: {str(e)}", exc_info=True)
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
